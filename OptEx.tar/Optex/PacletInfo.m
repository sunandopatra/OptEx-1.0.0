(* Paclet Info File *)

(* created 2018/10/25*)

Paclet[
    Name -> "OptEx",
    Version -> "0.0.1",
    MathematicaVersion -> "10+",
    Description -> "A practical optimization tool to combine experimental results in presence or absence of underlying theory. It estimates the free parameters of the theory and gives confidence intervals (1D and 2D).",
    Creator -> "Sunando Kr. Patra, Anisha",
    Extensions -> 
        {
            {"Documentation", Language -> "English"}
        }
]


