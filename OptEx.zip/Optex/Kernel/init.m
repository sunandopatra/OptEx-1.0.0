(* Wolfram Language Init File *)

Get[ "OptEx`OptEx`"]